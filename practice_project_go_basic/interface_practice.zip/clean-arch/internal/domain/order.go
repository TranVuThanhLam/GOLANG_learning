package domain

type Order struct {
	ID     string
	Amount float64
}
