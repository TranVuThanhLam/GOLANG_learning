package handler

import (
	"context"
	"clean-arch/internal/domain"
	"clean-arch/internal/usecase"
)

type CreateOrderRequest struct {
	ID     string
	Amount float64
}

type OrderHandler struct {
	placeOrder usecase.PlaceOrder
}

func NewOrderHandler(placeOrder usecase.PlaceOrder) *OrderHandler {
	return &OrderHandler{placeOrder: placeOrder}
}

func (h *OrderHandler) CreateOrder(ctx context.Context, req CreateOrderRequest) error {
	order := domain.Order{
		ID:     req.ID,
		Amount: req.Amount,
	}

	return h.placeOrder.Execute(ctx, order)
}
