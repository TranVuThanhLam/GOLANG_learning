package usecase

import (
	"clean-arch/internal/domain"
	"context"
)

type placeOrderUseCase struct {
	payment  PaymentProcessor
	notifier Notifier
	logger   Logger
}

func NewPlaceOrderUseCase(
	p PaymentProcessor,
	n Notifier,
	l Logger,
) PlaceOrder {
	return &placeOrderUseCase{
		payment:  p,
		notifier: n,
		logger:   l,
	}
}

func (uc *placeOrderUseCase) Execute(ctx context.Context, order domain.Order) error {
	uc.logger.Info(ctx, "[ORDER] Đang xử lí order", "order_id", order.ID, "amount", order.Amount)
	if err := uc.payment.Pay(ctx, order); err != nil {
		uc.logger.Info(ctx, "[ERROR] Thanh toán thất bại", "order_id", order.ID, "error", err)
		return err
	}

	uc.logger.Info(ctx, "[ORDER] Thanh toán thành công", "order_id", order.ID)
	if err := uc.notifier.Notify(ctx, order); err != nil {
		uc.logger.Info(ctx, "[ERROR] Thông báo thất bại", "order_id", order.ID, "error", err)
		return err
	}

	uc.logger.Info(ctx, "[ORDER] Order đã hoàn thành", "order_id", order.ID)
	return nil
}
