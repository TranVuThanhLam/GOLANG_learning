package usecase

import (
	"clean-arch/internal/domain"
	"context"
)

type PaymentProcessor interface {
	Pay(ctx context.Context, order domain.Order) error
}

type Notifier interface {
	Notify(ctx context.Context, order domain.Order) error
}

type Logger interface {
	Info(ctx context.Context, msg string, keysAndValues ...interface{})
}

// PlaceOrder is the abstraction for the place order use case.
type PlaceOrder interface {
	Execute(ctx context.Context, order domain.Order) error
}
