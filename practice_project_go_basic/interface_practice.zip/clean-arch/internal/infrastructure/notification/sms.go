package notification

import (
	"context"
	"clean-arch/internal/domain"
)

type SMSNotifier struct{}

func (s *SMSNotifier) Notify(ctx context.Context, order domain.Order) error {
	// TODO: implement SMS sending; placeholder for now
	_ = s
	return nil
}
