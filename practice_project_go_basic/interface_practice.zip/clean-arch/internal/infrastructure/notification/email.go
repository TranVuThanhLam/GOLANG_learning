package notification

import (
	"context"
	"clean-arch/internal/domain"
)

type EmailNotifier struct {
	Message string
}

func (e *EmailNotifier) Notify(ctx context.Context, order domain.Order) error {
	// TODO: implement real email sending; placeholder for now
	_ = e.Message
	return nil
}
