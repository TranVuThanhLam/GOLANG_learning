package payment

import (
	"context"
	"clean-arch/internal/domain"
)

type CreditCardPayment struct {
	Amount float64
}

func (c *CreditCardPayment) Pay(ctx context.Context, order domain.Order) error {
	// TODO: integrate with real credit card gateway; placeholder for now
	_ = c.Amount
	return nil
}
