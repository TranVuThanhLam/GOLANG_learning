package payment

import (
	"context"
	"clean-arch/internal/domain"
)

type PaypalPayment struct{}

func (p *PaypalPayment) Pay(ctx context.Context, order domain.Order) error {
	// TODO: integrate with PayPal SDK; placeholder for now
	_ = p
	return nil
}
