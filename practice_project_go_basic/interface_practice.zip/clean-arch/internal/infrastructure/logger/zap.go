package logger

import (
	"clean-arch/internal/usecase"
	"context"
	"fmt"
	"strings"
)

type ZapLogger struct{}

func NewZapLogger() usecase.Logger { return &ZapLogger{} }

func (z *ZapLogger) Info(ctx context.Context, msg string, keysAndValues ...interface{}) {
	_ = ctx

	if len(keysAndValues) == 0 {
		fmt.Println(msg)
		return
	}

	parts := make([]string, 0, (len(keysAndValues)+1)/2)
	for i := 0; i < len(keysAndValues); i += 2 {
		key := fmt.Sprint(keysAndValues[i])
		val := ""
		if i+1 < len(keysAndValues) {
			val = fmt.Sprint(keysAndValues[i+1])
		}
		parts = append(parts, fmt.Sprintf("%s=%s", key, val))
	}

	fmt.Printf("%s | %s\n", msg, strings.Join(parts, " "))
}
