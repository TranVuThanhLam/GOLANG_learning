package main

import (
	"clean-arch/internal/handler"
	"clean-arch/internal/infrastructure/logger"
	"clean-arch/internal/infrastructure/notification"
	"clean-arch/internal/infrastructure/payment"
	"clean-arch/internal/usecase"
	"context"
)

func main() {
	ctx := context.Background()
	log := logger.NewZapLogger()

	paymentProcessor := &payment.CreditCardPayment{Amount: 5623.3}
	notifier := &notification.EmailNotifier{Message: "Order confirmation"}

	placeOrderUC := usecase.NewPlaceOrderUseCase(
		paymentProcessor,
		notifier,
		log,
	)

	orderHandler := handler.NewOrderHandler(placeOrderUC)
	_ = orderHandler.CreateOrder(ctx, handler.CreateOrderRequest{ID: "123", Amount: 5623.3})

	paypalPayment := &payment.PaypalPayment{}
	smsNotifier := &notification.SMSNotifier{}

	placeOrder := usecase.NewPlaceOrderUseCase(
		paypalPayment,
		smsNotifier,
		log,
	)

	orderHandler = handler.NewOrderHandler(placeOrder)
	_ = orderHandler.CreateOrder(ctx, handler.CreateOrderRequest{ID: "456", Amount: 100})

}
