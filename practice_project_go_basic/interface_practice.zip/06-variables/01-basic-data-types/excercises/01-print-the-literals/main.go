package main

import "fmt"

func main() {
	// TODO: [DEBUG] - DELETE ME BEFORE COMMIT
	// @location: main.go
	fmt.Printf("\n\033[1;33m--- DEBUG START ---\033[0m\n📍 \033[1;34mFile/Line:\033[0m main.go:4\n🛠  \033[1;32mFunction:\033[0m funcName\n📦 \033[1;35mValue:\033[0m %+v\n\033[1;33m--------------------\033[0m\n", "oke")
	// ------------------------------------------
	
}
