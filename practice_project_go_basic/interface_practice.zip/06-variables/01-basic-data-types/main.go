package main

import "fmt"

func main() {
	// interger literal
	fmt.Println(
		-200, -200, 0, 50, 100, 100,
	)

	// float literal
	fmt.Println(
		-50.5, -20.5, -0., 1., 100.56,
	)

	// boolean literal
	fmt.Println(
		true, false,
	)

	// string literal
	fmt.Println(
		"Hello, World!", "Go is awesome!",
	)
}
