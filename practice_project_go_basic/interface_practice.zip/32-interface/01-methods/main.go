package main

func main() {
	mobydick := Book{
		title: "moby dick",
		price: 10,
	}

	minecraft := Game{
		title: "minecraft",
		price: 20,
	}

	tetris := Game{
		title: "tetris",
		price: 5,
	}

	mobydick.print()
	minecraft.print()
	tetris.print()
}
