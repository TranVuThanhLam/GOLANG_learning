package main

import "fmt"

type Book struct {
	title string
	price int
}

func (b Book) print() {
	fmt.Printf("Book: %s, Price: %d\n", b.title, b.price)
}
