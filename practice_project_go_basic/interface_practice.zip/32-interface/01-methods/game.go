package main

import "fmt"

type Game struct {
	title string
	price int
}

func (g Game) print() {
	fmt.Printf("Game: %s, price: %d\n", g.title, g.price)
}
