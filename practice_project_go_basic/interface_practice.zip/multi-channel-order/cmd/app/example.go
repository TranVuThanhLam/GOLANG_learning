package main

import (
	"fmt"
	"multi-channel-order/internal/dto"
	"multi-channel-order/internal/mock"
	"multi-channel-order/internal/notification"
	"multi-channel-order/internal/order"
	"multi-channel-order/internal/payment"
)

func example1() {
	creditCardPayment := &payment.CreditCardPayment{
		CardNumber: "4111-1111-1111-1111",
		CVV:        "123",
	}

	emailNotifier := &notification.EmailNotifier{
		From: "lamtvt@company.com",
		To:   "customer@example.com",
	}

	// Dependency Injection - OrderService không biết concrete type của Payer & Notifier
	orderService := order.NewOrderService(creditCardPayment, emailNotifier, logger)

	order1 := dto.NewOrder("ORD-001", 99.99)
	_ = orderService.PlaceOrder(order1)
}

func example2() {
	paypalPayment := &payment.PayPalPayment{
		Email: "lamtvt@paypal.com",
	}

	smsNotifier := &notification.SMSNotifier{
		PhoneNumber: "+84912345678",
	}

	orderService2 := order.NewOrderService(paypalPayment, smsNotifier, logger)

	order2 := dto.NewOrder("ORD-002", 199.99)
	orderService2.PlaceOrder(order2)
}

func example3() {
	bankPayment := &payment.BankTransferPayment{
		AccountNumber: "1234567890",
		BankCode:      "VCB",
	}

	slackNotifier := &notification.SlackNotifier{
		WebhookURL: "https://hooks.slack.com/services/...",
		Channel:    "#orders",
	}

	orderService3 := order.NewOrderService(bankPayment, slackNotifier, logger)

	order3 := dto.NewOrder("ORD-003", 299.99)
	orderService3.PlaceOrder(order3)
}

func example4() {

	mockPayment := &mock.MockPayment{}
	mockNotifier := &mock.MockNotifier{}
	mockLogger := &mock.MockLogger{}

	orderService4 := order.NewOrderService(mockPayment, mockNotifier, mockLogger)

	order4 := dto.NewOrder("ORD-TEST", 50.00)
	orderService4.PlaceOrder(order4)

	fmt.Printf("Mock Payment Called: %v (%d times)\n", mockPayment.Called, mockPayment.CallCount)
	fmt.Printf("Mock Notifier Called: %v (%d times)\n", mockNotifier.Called, mockNotifier.CallCount)
	fmt.Printf("Mock Logger Messages: %d\n\n", len(mockLogger.GetMessages()))
}

func example5() {
	creditCardPayment := &payment.CreditCardPayment{
		CardNumber: "4111-1111-1111-1111",
		CVV:        "123",
	}
	paypalPayment := &payment.PayPalPayment{
		Email: "lamtvt@paypal.com",
	}
	bankPayment := &payment.BankTransferPayment{
		AccountNumber: "1234567890",
		BankCode:      "VCB",
	}
	DebugPaymentProcessor(creditCardPayment)
	DebugPaymentProcessor(paypalPayment)
	DebugPaymentProcessor(bankPayment)
}

func example6() {
	multiNotifier := notification.NewMultiNotifier(
		&notification.EmailNotifier{From: "noreply@store.com", To: "admin@store.com"},
		&notification.SlackNotifier{WebhookURL: "...", Channel: "#notifications"},
	)
	creditCardPayment := &payment.CreditCardPayment{
		CardNumber: "4111-1111-1111-1111",
		CVV:        "123",
	}
	orderService5 := order.NewOrderService(creditCardPayment, multiNotifier, logger)

	order5 := dto.NewOrder("ORD-005", 349.99)
	_ = orderService5.PlaceOrder(order5)
}

func example7() {

	creditCardPayment := &payment.CreditCardPayment{
		CardNumber: "4111-1111-1111-1111",
		CVV:        "123",
	}
	emailNotifier := &notification.EmailNotifier{
		From: "lamtvt@company.com",
		To:   "customer@example.com",
	}
	orderService := order.NewOrderService(creditCardPayment, emailNotifier, logger)
	orderWithZeroAmount := dto.NewOrder("ORD-ZERO", 0)
	err := orderService.PlaceOrder(orderWithZeroAmount)
	if err != nil {
		fmt.Printf("Order failed: %v\n\n", err)
	}
}

func example8() {
	creditCardPayment := &payment.CreditCardPayment{
		CardNumber: "4111-1111-1111-1111",
		CVV:        "123",
	}
	paypalPayment := &payment.PayPalPayment{
		Email: "lamtvt@paypal.com",
	}
	bankPayment := &payment.BankTransferPayment{
		AccountNumber: "1234567890",
		BankCode:      "VCB",
	}
	paymentProcessors := []order.Payer{
		creditCardPayment,
		paypalPayment,
		bankPayment,
	}

	testOrder := dto.NewOrder("ORD-POLY", 100.00)

	for i, processor := range paymentProcessors {
		fmt.Printf("💡 Bộ xử lý thanh toán #%d:\n", i+1)
		if err := processor.Pay(testOrder); err != nil {
			fmt.Printf("Lỗi: %v\n", err)
		}
	}
}

func example9() {
	order1 := dto.NewOrder("ORD-001", 99.99)

	LogAnything("Hello World")
	LogAnything(12345)
	LogAnything(99.99)
	LogAnything(order1)
	LogAnything([]string{"a", "b", "c"})
}

// Empty Interface & any
// Accept any type
func LogAnything(data any) {
	switch v := data.(type) {
	case string:
		fmt.Printf("🔹 String: %q\n", v)
	case int:
		fmt.Printf("🔹 Integer: %d\n", v)
	case float64:
		fmt.Printf("🔹 Float: %.2f\n", v)
	case *dto.Order:
		fmt.Printf("🔹 Order: ID=%s, Amount=$%.2f\n", v.ID, v.Amount)
	case []string:
		fmt.Printf("🔹 String Slice: %v\n", v)
	default:
		fmt.Printf("🔹 Unknown type: %T = %v\n", data, data)
	}
}
