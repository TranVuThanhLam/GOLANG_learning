package main

import (
	"fmt"
	"multi-channel-order/internal/order"
	"multi-channel-order/internal/payment"
)

// Helper function to create separator
func createSeparator(char string, count int) string {
	result := ""
	for i := 0; i < count; i++ {
		result += char
	}
	return result
}

func printAppHeader() {
	fmt.Println("\n" + sepEqual)
	fmt.Println("Multi-Channel Order Processing System")
	fmt.Println(sepEqual + "\n")
}

func (c *ConsoleLogger) Log(msg string) {
	fmt.Println(msg)
}

// Type Assertion + Type Switch
// Handle differently based on payment type
func DebugPaymentProcessor(p order.Payer) {
	fmt.Printf("💡 Debugging payment processor:\n")

	switch v := p.(type) {
	case *payment.CreditCardPayment:
		fmt.Printf("   Type: Credit Card\n")
		fmt.Printf("   Card: %s\n", v.CardNumber)

	case *payment.PayPalPayment:
		fmt.Printf("   Type: PayPal\n")
		fmt.Printf("   Email: %s\n", v.Email)

	case *payment.BankTransferPayment:
		fmt.Printf("   Type: Bank Transfer\n")
		fmt.Printf("   Account: %s\n", v.AccountNumber)

	default:
		fmt.Printf("   Type: Unknown\n")
	}
	fmt.Println()
}
