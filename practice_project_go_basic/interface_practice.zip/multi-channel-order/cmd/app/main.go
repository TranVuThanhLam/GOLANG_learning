package main

import (
	"fmt"
)

// Logger đơn giản
type ConsoleLogger struct{}

var sepEqual = createSeparator("=", 60)
var sepDash = createSeparator("-", 60)
var logger = &ConsoleLogger{}

func main() {
	printAppHeader()

	// ========================================
	// fmt.Println("\nVí dụ 1: Thẻ Credit + thông báo Email")
	// fmt.Println(sepDash)
	// example1()
	// // ========================================
	// fmt.Println("\nVí dụ 2: PayPal + thông báo SMS")
	// fmt.Println(sepDash)
	// example2()
	// // ========================================
	// fmt.Println("\nVí dụ 3: Chuyển khoản ngân hàng + thông báo Slack")
	// fmt.Println(sepDash)
	// example3()
	// // ========================================
	// fmt.Println("\nVí dụ 4: Mock Objects for Testing")
	// fmt.Println(sepDash)
	// example4()
	// // ========================================
	// fmt.Println("\nVí dụ 5: Type Assertion & Type Switch")
	// fmt.Println(sepDash)
	// example5()
	// // ========================================
	// fmt.Println("\nVí dụ 6: Multi-Notifier (Gửi đến nhiều kênh)")
	// fmt.Println(sepDash)
	// example6()
	// // ========================================
	fmt.Println("\nVí dụ 7: Xử lý lỗi tùy chỉnh")
	fmt.Println(sepDash)
	example7()
	// // ========================================
	// fmt.Println("\nVí dụ 8: Đa hình - Cùng Interface, Hành vi khác nhau")
	// fmt.Println(sepDash)
	// example8()
	// // ========================================
	// fmt.Println("\nVí dụ 9: Empty Interface & 'any'")
	// fmt.Println(sepDash)
	// example9()
	// // ========================================

	fmt.Println("\n" + sepEqual)
	fmt.Println("\t\t\tDemo completed!")
	fmt.Println(sepEqual + "\n")
}
