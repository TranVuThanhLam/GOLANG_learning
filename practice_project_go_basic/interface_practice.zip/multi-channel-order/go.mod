module multi-channel-order

go 1.22
