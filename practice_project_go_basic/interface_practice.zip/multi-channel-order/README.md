# 🎯 Multi-Channel Order Processing System

Một dự án Go showcase **Interface và Go-idiomatic patterns**

## 📊 Project Structure

```
multi-channel-order/
├── cmd/app/
│   └── main.go                 # Entry point, 9 example demos
│
├── internal/
│   ├── domain/
│   │   └── order.go            # Entity - NO interface
│   ├── order/
│   │   └── service.go          # Interfaces + OrderService
│   ├── payment/
│   │   └── payment.go          # 3 payment implementations
│   ├── notification/
│   │   └── notification.go     # 3 notifiers + MultiNotifier
│   ├── errors/
│   │   └── errors.go           # Custom error types
│   └── mock/
│       └── mocks.go            # Mock implementations for testing
└── go.mod
```

## 🔑 Core Concepts Demonstrated

### 1️⃣ **Interface Nhỏ - Go Philosophy**
```go
type Payer interface {
    Pay(order *domain.Order) error
}

type Notifier interface {
    Notify(order *domain.Order) error
}

type Logger interface {
    Log(msg string)
}
```

✅ **Lợi ích:**
- Mỗi interface chỉ có 1 method
- Clients không bị force implement không cần
- Dễ mock cho testing

### 2️⃣ **Implicit Implementation**
```go
// Không cần implements keyword
type CreditCardPayment struct { ... }

func (c *CreditCardPayment) Pay(order *Order) error {
    // implementation
}

// CreditCardPayment automatically implements Payer interface
```

✅ **Ưu điểm:**
- Duck typing - "If it walks like a duck..."
- Loose coupling
- Dễ thêm implementation mới mà không touch code cũ

### 3️⃣ **Interface Composition**
```go
type OrderService interface {
    PlaceOrder(order *Order) error
}

type service struct {
    payer    Payer      // Use interface
    notifier Notifier   // Use interface
    logger   Logger     // Use interface
}
```

✅ **Fayability:**
- High-level module không phụ thuộc concrete implementation
- Dependency Inversion Principle

### 4️⃣ **Constructor Injection**
```go
func NewOrderService(
    p Payer,
    n Notifier,
    l Logger,
) OrderService {
    return &service{
        payer:    p,
        notifier: n,
        logger:   l,
    }
}
```

✅ **100% testable** - pass mock objects

### 5️⃣ **Type Assertion & Type Switch**
```go
func DebugPaymentProcessor(p Payer) {
    switch v := p.(type) {
    case *CreditCardPayment:
        fmt.Printf("Credit Card: %s\n", v.CardNumber)
    case *PayPalPayment:
        fmt.Printf("PayPal: %s\n", v.Email)
    default:
        fmt.Println("Unknown type")
    }
}
```

✅ **Runtime type checking:**
- `v := p.(type)` - type assertion in switch
- Xử lý khác nhau dựa trên concrete type

### 6️⃣ **Empty Interface & `any`**
```go
func LogAnything(data any) {
    switch v := data.(type) {
    case string:
        fmt.Printf("String: %q\n", v)
    case int:
        fmt.Printf("Integer: %d\n", v)
    case *Order:
        fmt.Printf("Order: %v\n", v)
    default:
        fmt.Printf("Unknown: %v\n", data)
    }
}
```

✅ **Linh hoạt:**
- `any` = `interface{}`
- Chấp nhận bất kỳ type nào
- Type checking qua `.(type)`

### 7️⃣ **Custom Error Implementation**
```go
type PaymentError struct {
    Code    string
    Message string
}

// Implement error interface
func (e *PaymentError) Error() string {
    return fmt.Sprintf("[%s] %s", e.Code, e.Message)
}
```

✅ **Go error pattern:**
- `error` chỉ là interface với 1 method
- Bất kỳ type nào implement `Error() string` là error

### 8️⃣ **Polymorphism**
```go
paymentProcessors := []Payer{
    &CreditCardPayment{...},
    &PayPalPayment{...},
    &BankTransferPayment{...},
}

for _, p := range paymentProcessors {
    p.Pay(order)  // Polymorphic call
}
```

✅ **Same interface, different behavior**

### 9️⃣ **Testing with Mock**
```go
type MockPayment struct {
    Called   bool
    CallCount int
}

func (m *MockPayment) Pay(order *Order) error {
    m.Called = true
    m.CallCount++
    return nil
}

// Use in test
mock := &MockPayment{}
service := order.NewOrderService(mock, mockNotifier, mockLogger)
service.PlaceOrder(order)

assert mock.Called == true
```

✅ **Không cần:**
- Database
- API calls
- Fixtures

## 🚀 Running Examples

```bash
cd multi-channel-order
go run cmd/app/main.go
```

Output: 9 complete examples showing all concepts

### Example Output:
```
📌 EXAMPLE 1: Credit Card + Email Notification
[ORDER] Processing order ORD-001 with amount 99.99
💳 Processing credit card payment
   Card: 4111-1111-1111-1111, Amount: $99.99
   ✅ Payment successful

[ORDER] Payment successful for order ORD-001
📧 Sending email notification
   From: noreply@store.com, To: customer@example.com
   Subject: Order ORD-001 confirmed
   ✅ Email sent

[ORDER] Order ORD-001 completed
```

## 📚 File-by-File Breakdown

### `internal/domain/order.go`
- ✅ Pure business object
- ✅ NO interface
- ✅ NO external dependencies

### `internal/order/service.go`
- 🔹 Define **WHAT** it needs (interfaces)
- 🔹 NOT **HOW** to do it (concrete types)
- 🔹 OrderService uses Payer, Notifier, Logger interfaces

### `internal/payment/payment.go`
- 3 implementations: CreditCard, PayPal, BankTransfer
- Each implements `Payer` interface implicitly
- No knowledge of how they're used

### `internal/notification/notification.go`
- 3 implementations: Email, SMS, Slack
- MultiNotifier - compose multiple notifiers
- Each implements `Notifier` interface implicitly

### `internal/errors/errors.go`
- Custom error types
- Implement `error` interface
- Helper functions for error handling

### `internal/mock/mocks.go`
- Mock implementations for testing
- 100% control over behavior

### `cmd/app/main.go`
- 9 complete examples
- Composition root - where concrete objects are created
- Type assertion demos
- Polymorphism demos

## 🎓 Learning Outcomes

After studying this project, you'll understand:

1. ✅ Go interface design philosophy
2. ✅ Implicit implementation & duck typing
3. ✅ Dependency injection patterns
4. ✅ Loose coupling, high cohesion
5. ✅ Type assertion & type switching
6. ✅ Empty interface & generic handling
7. ✅ Error handling patterns in Go
8. ✅ Testing with mock objects
9. ✅ Composition over inheritance
10. ✅ SOLID principles in Go

## 🔗 Key SOLID Principles Applied

- **S** - Single Responsibility: Each interface has 1 method
- **O** - Open/Closed: Easy to add new payment/notification types without modifying existing code
- **L** - Liskov Substitution: Any Payer can be used interchangeably
- **I** - Interface Segregation: Small, focused interfaces
- **D** - Dependency Inversion: Depend on abstractions (interfaces), not concrete types

## 💡 Real-World Applications

- ✅ Payment processing systems
- ✅ Multi-channel notification systems
- ✅ Plugin architectures
- ✅ Microservices with adapters
- ✅ Testable business logic
- ✅ Strategy pattern implementations
