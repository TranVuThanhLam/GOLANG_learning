package payment

import (
	"fmt"
	"multi-channel-order/internal/dto"
	"multi-channel-order/internal/errors"
)

// Bank Transfer Payment
type BankTransferPayment struct {
	AccountNumber string
	BankCode      string
}

func (b *BankTransferPayment) Pay(order *dto.Order) error {
	if order.Amount <= 0 {
		return errors.NewPaymentError("INVALID_AMOUNT", "Amount must be positive")
	}

	fmt.Printf("\tProcessing bank transfer\n")
	fmt.Printf("\tAccount: %s, Amount: $%.2f\n", b.AccountNumber, order.Amount)
	fmt.Printf("\t...\n")
	fmt.Printf("\tPayment successful!!!\n\n")

	return nil
}
