package payment

import (
	"fmt"
	"multi-channel-order/internal/dto"
	"multi-channel-order/internal/errors"
)

// CreditCard Payment
type CreditCardPayment struct {
	CardNumber string
	CVV        string
}

// Implicit implementation
func (c *CreditCardPayment) Pay(order *dto.Order) error {
	if order.Amount <= 0 {
		return errors.NewPaymentError("INVALID_AMOUNT", "Amount must be positive")
	}

	fmt.Printf("\tProcessing credit card payment...\n")
	fmt.Printf("\tCard: %s, Amount: $%.2f\n", c.CardNumber, order.Amount)
	fmt.Printf("\t...\n")
	fmt.Printf("\tPayment successful!!!\n\n")

	return nil
}
