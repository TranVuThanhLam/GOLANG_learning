package payment

import (
	"fmt"
	"multi-channel-order/internal/dto"
	"multi-channel-order/internal/errors"
)

// PayPal Payment
type PayPalPayment struct {
	Email string
}

func (p *PayPalPayment) Pay(order *dto.Order) error {
	if order.Amount <= 0 {
		return errors.NewPaymentError("INVALID_AMOUNT", "Amount must be positive")
	}

	fmt.Printf("\tProcessing PayPal payment\n")
	fmt.Printf("\tEmail: %s, Amount: $%.2f\n", p.Email, order.Amount)
	fmt.Printf("\t...\n")
	fmt.Printf("\tPayment successful!!!\n\n")

	return nil
}
