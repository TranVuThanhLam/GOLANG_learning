package errors

import "fmt"

// PaymentError - custom error implementation
type PaymentError struct {
	Code    string
	Message string
}

// PaymentError implements error interface
func (e *PaymentError) Error() string {
	return fmt.Sprintf("[%s] %s", e.Code, e.Message)
}

func NewPaymentError(code, message string) *PaymentError {
	return &PaymentError{
		Code:    code,
		Message: message,
	}
}

// OrderError - custom error
type OrderError struct {
	Code    string
	Message string
}

func (e *OrderError) Error() string {
	return fmt.Sprintf("[%s] %s", e.Code, e.Message)
}

func NewOrderError(code, message string) *OrderError {
	return &OrderError{
		Code:    code,
		Message: message,
	}
}

// Error type assertion helpers
func IsPaymentError(err error) bool {
	_, ok := err.(*PaymentError)
	return ok
}

func GetPaymentErrorCode(err error) string {
	if pe, ok := err.(*PaymentError); ok {
		return pe.Code
	}
	return "UNKNOWN"
}
