package mock

import (
	"fmt"
	"multi-channel-order/internal/dto"
)

// Mock Payment - for testing
type MockPayment struct {
	Called     bool
	CallCount  int
	ShouldFail bool
}

func (m *MockPayment) Pay(order *dto.Order) error {
	m.Called = true
	m.CallCount++

	if m.ShouldFail {
		return fmt.Errorf("mock payment failed")
	}

	fmt.Printf("[MOCK] Processing payment for order %s\n\n", order.ID)
	return nil
}

// Mock Notifier - for testing
type MockNotifier struct {
	Called    bool
	CallCount int
	LastOrder *dto.Order
}

func (m *MockNotifier) Notify(order *dto.Order) error {
	m.Called = true
	m.CallCount++
	m.LastOrder = order

	fmt.Printf("[MOCK] Sending notification for order %s\n\n", order.ID)
	return nil
}

// Mock Logger - for testing
type MockLogger struct {
	Messages []string
}

func (m *MockLogger) Log(msg string) {
	m.Messages = append(m.Messages, msg)
	fmt.Printf("[MOCK LOG] %s\n", msg)
}

func (m *MockLogger) GetMessages() []string {
	return m.Messages
}
