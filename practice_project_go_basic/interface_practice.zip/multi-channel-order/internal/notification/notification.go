package notification

import (
	"fmt"
	"multi-channel-order/internal/dto"
)

// Multi-notifier - send to multiple channels
type MultiNotifier struct {
	notifiers []interface {
		Notify(order *dto.Order) error
	}
}

func NewMultiNotifier(notifiers ...interface {
	Notify(order *dto.Order) error
}) *MultiNotifier {
	return &MultiNotifier{notifiers: notifiers}
}

func (m *MultiNotifier) Notify(order *dto.Order) error {
	for _, n := range m.notifiers {
		if err := n.Notify(order); err != nil {
			return err
		}
	}
	return nil
}

// SMS Notification
type SMSNotifier struct {
	PhoneNumber string
}

func (s *SMSNotifier) Notify(order *dto.Order) error {
	fmt.Printf("\tSending SMS notification\n")
	fmt.Printf("\tPhone: %s\n", s.PhoneNumber)
	fmt.Printf("\tMessage: Order %s confirmed\n", order.ID)
	fmt.Printf("\tSMS sent!!!\n\n")

	return nil
}
