package notification

import (
	"fmt"
	"multi-channel-order/internal/dto"
)

// Slack Notification
type SlackNotifier struct {
	WebhookURL string
	Channel    string
}

func (s *SlackNotifier) Notify(order *dto.Order) error {
	fmt.Printf("\tSending Slack notification\n")
	fmt.Printf("\tChannel: %s\n", s.Channel)
	fmt.Printf("\tMessage: Order %s confirmed - Amount: $%.2f\n", order.ID, order.Amount)
	fmt.Printf("\tSlack message sent!!!\n\n")

	return nil
}
