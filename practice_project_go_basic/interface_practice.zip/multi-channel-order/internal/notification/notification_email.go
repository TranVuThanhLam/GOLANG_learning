package notification

import (
	"fmt"
	"multi-channel-order/internal/dto"
)

// Email Notification
type EmailNotifier struct {
	From string
	To   string
}

// Implicit implementation
func (e *EmailNotifier) Notify(order *dto.Order) error {
	fmt.Printf("\tSending email notification\n")
	fmt.Printf("\tFrom: %s, To: %s\n", e.From, e.To)
	fmt.Printf("\tSubject: Order %s confirmed\n", order.ID)
	fmt.Printf("\tEmail sent!!!\n\n")

	return nil
}
