package order

import (
	"fmt"
	"multi-channel-order/internal/dto"
)

// Concrete implementation
type service struct {
	payer    Payer
	notifier Notifier
	logger   Logger
}

// NewOrderService - constructor injection
func NewOrderService(p Payer, n Notifier, l Logger) OrderService {
	return &service{
		payer:    p,
		notifier: n,
		logger:   l,
	}
}

// PlaceOrder - business logic
func (s *service) PlaceOrder(order *dto.Order) error {
	s.logger.Log(fmt.Sprintf("[ORDER] Đang xử lí order %s với số tiền %.2f", order.ID, order.Amount))

	// Process payment
	if err := s.payer.Pay(order); err != nil {
		s.logger.Log(fmt.Sprintf("[ERROR] Thanh toán thất bại: %v", err))
		return err
	}

	order.Status = "paid"
	s.logger.Log(fmt.Sprintf("[ORDER] Thanh toán thành công cho order %s", order.ID))
	// Send notification
	if err := s.notifier.Notify(order); err != nil {
		s.logger.Log(fmt.Sprintf("[ERROR] Thông báo thất bại: %v", err))
		return err
	}

	order.Status = "completed"
	s.logger.Log(fmt.Sprintf("[ORDER] Order %s đã hoàn thành", order.ID))

	return nil
}
