package order

import "multi-channel-order/internal/dto"

// Interface nhỏ - Go philosophy
type Payer interface {
	Pay(order *dto.Order) error
}

type Notifier interface {
	Notify(order *dto.Order) error
}

type Logger interface {
	Log(msg string)
}

// Interface composition
type OrderService interface {
	PlaceOrder(order *dto.Order) error
}
