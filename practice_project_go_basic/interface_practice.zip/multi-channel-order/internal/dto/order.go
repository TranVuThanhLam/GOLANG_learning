package dto

// Order - order cơ bản
type Order struct {
	ID     string
	Amount float64
	Status string
}

// NewOrder - tạo order mới
func NewOrder(id string, amount float64) *Order {
	return &Order{
		ID:     id,
		Amount: amount,
		Status: "pending",
	}
}
