Chỉ cần import Gin vào code thì GO sẽ tự động tải package trong quá trình build

go get github.com/mattn/go-sqlite3

go get -u golang.org/x/crypto

go get -u github.com/golang-jwt/jwt/v5